package com.example.basketball;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.content.Intent;
import com.example.basketball.databinding.ActivityMainBinding;

public class MainActivity extends AppCompatActivity {

    private ActivityMainBinding binding;
    public static final String EXTRA_LOCAL = "EXTRA_LOCAL";
    public static final String EXTRA_VISIT = "EXTRA_VISIT";

    private int scoreLocal = 0;
    private int scoreVisit = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        binding = ActivityMainBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        // Botones Local
        binding.btnLocalMas1.setOnClickListener(v -> sumarLocal(1));
        binding.btnLocalMas2.setOnClickListener(v -> sumarLocal(2));
        binding.btnLocalMenos1.setOnClickListener(v -> restarLocal());

        // Botones Visitante
        binding.btnVisitMas1.setOnClickListener(v -> sumarVisit(1));
        binding.btnVisitMas2.setOnClickListener(v -> sumarVisit(2));
        binding.btnVisitMenos1.setOnClickListener(v -> restarVisit());

        // Reset
        binding.btnReset.setOnClickListener(v -> resetMarkers());

        // Ir a resultados
        binding.btnResultados.setOnClickListener(v -> {
            Intent intent = new Intent(MainActivity.this, ScoreActivity.class);
            intent.putExtra(EXTRA_LOCAL, scoreLocal);
            intent.putExtra(EXTRA_VISIT, scoreVisit);
            startActivity(intent);
        });
    }

    private void sumarLocal(int pts) {
        scoreLocal += pts;
        binding.txtScoreLocal.setText(String.valueOf(scoreLocal));
    }

    private void sumarVisit(int pts) {
        scoreVisit += pts;
        binding.txtScoreVisitante.setText(String.valueOf(scoreVisit));
    }

    private void restarLocal() {
        if (scoreLocal > 0) scoreLocal--;
        binding.txtScoreLocal.setText(String.valueOf(scoreLocal));
    }

    private void restarVisit() {
        if (scoreVisit > 0) scoreVisit--;
        binding.txtScoreVisitante.setText(String.valueOf(scoreVisit));
    }

    private void resetMarkers() {
        scoreLocal = 0;
        scoreVisit = 0;
        binding.txtScoreLocal.setText("0");
        binding.txtScoreVisitante.setText("0");
    }
}
