package com.example.basketball;

import com.example.basketball.databinding.ActivityScoreBinding;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;

public class ScoreActivity extends AppCompatActivity {

    private ActivityScoreBinding binding;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        binding = ActivityScoreBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        int local = getIntent().getIntExtra(MainActivity.EXTRA_LOCAL, 0);
        int visit = getIntent().getIntExtra(MainActivity.EXTRA_VISIT, 0);

        binding.txtResultado.setText(local + " - " + visit);

        if (local > visit) {
            binding.txtGanador.setText("Ganó el equipo local");
        } else if (visit > local) {
            binding.txtGanador.setText("Ganó el equipo visitante");
        } else {
            binding.txtGanador.setText("Empate");
        }
    }
}

